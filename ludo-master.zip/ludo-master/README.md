ludo
====

HTML 5 ludo game

Game has computer simulation, for up to 4 players

- FIXED:
* Moving a second piece on to another color's safe-field where the there is a safe piece leaves count at 1 (should be 2)
* When there is one piece on it's safe-field and two of another color's pieces the count for the field is 1 (should be 2)
* When another color has a piece on a players safe-field and the player roll's a 6 the player's piece should be offset when it get's to the safe-field
* Moving a piece from the homestretch directly into the goal-area leaves the homestretch field count at 1 (should be 0)


- TODO:
* Make playable over network using WebSockets